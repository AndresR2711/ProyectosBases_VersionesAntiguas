package com.example.lab

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val dolaresEditText = findViewById<EditText>(R.id.Dolares)
        val valorconversionTextView = findViewById<TextView>(R.id.precioConver)
        val convertButton = findViewById<Button>(R.id.btnAplicar)
        val resultadoconversionTextView = findViewById<TextView>(R.id.tvResultado)
        val valorDolar = 542.60

        // Muestra el valor del dolar con el que se estara realizando la conversion
        valorconversionTextView.text = "1 dólar= $valorDolar colones"
        // Establece un Listener para el botón de conversión
        convertButton.setOnClickListener {
            // Se obtiene el valor ingresado por el usuario y se ingresa en una variable
            val dolares = dolaresEditText.text.toString()

            // Se crea un if para validad que los datos ingresados sean los correctos con el fin de evitar problemas o errores en el programa
            if (dolares.isEmpty() || !dolares.matches("-?\\d+(\\.\\d+)?".toRegex())) {
                // Si el valor no es válido, muestra un Toast con un mensaje de error y regresa sin hacer nada más
                Toast.makeText(this, "Por favor ingrese un valor válido en dólares", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // Convierte el valor de dólares a colones,ultiplicando por la variable llamada "valorDolar"
            val colones = dolares.toInt() * valorDolar

            // Muestra el resultado de la conversión en el TextView
            resultadoconversionTextView.text = "$colones colones"

        }
    }

}