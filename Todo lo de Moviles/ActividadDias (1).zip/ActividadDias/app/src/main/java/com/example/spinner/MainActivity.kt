package com.example.spinner

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //crear lista de transporte
        val diasSemana= arrayOf("Lunes", "Martes", "Miercoles","Jueves","Viernes","Sabado","Domingo")
        val adaptador= ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,diasSemana)
        adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        val spinner:Spinner=findViewById(R.id.spinnerDias)
        spinner.adapter=adaptador
        val tvDiasSemana:TextView=findViewById(R.id.tvDia)
        spinner.onItemSelectedListener=object :AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                val diaSeleccionado=parent.getItemAtPosition(position).toString()
                val dias=when(diaSeleccionado){
                    "Lunes"->"Lunes"
                    "Martes"->"Martes"
                    "Miercoles"->"Miercoles"
                    "Jueves"->"Jueves"
                    "Viernes"->"Viernes"
                    "Sabado"->"Sabado"
                    "Domingo"->"Domingo"
                    else->""
                }
                tvDiasSemana.text="$dias"
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }


    }
}