package com.example.tareaclima

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var edNomCiudad: EditText
    private lateinit var btBuscar: Button
    private lateinit var imgTiempo: ImageView
    private lateinit var tvTemperatura: TextView
    private lateinit var imgTemperatura: ImageView
    private lateinit var tvHumedad: TextView
    private lateinit var imgHumedad: ImageView
    private lateinit var tvDescripcion: TextView
    private lateinit var imgDescripcion: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edNomCiudad = findViewById(R.id.edNomCiudad)
        btBuscar = findViewById(R.id.btBuscar)
        imgTiempo = findViewById(R.id.imgTiempo)
        tvTemperatura = findViewById(R.id.tvTemperatura)
        imgTemperatura = findViewById(R.id.imgTemperatura)
        tvHumedad = findViewById(R.id.tvHumedad)
        imgHumedad = findViewById(R.id.imgHumedad)
        tvDescripcion = findViewById(R.id.tvDescripcion)
        imgDescripcion = findViewById(R.id.imgDescription)

        btBuscar.setOnClickListener {
            val ciudad = edNomCiudad.text.toString()
            runRequest(ciudad)
        }
    }

    private fun runRequest(ciudad: String) {
        //Api correspondiente
        val apiKey = "b82c6737e32ab73ede9050788dbadc73"
        val url = "https://api.openweathermap.org/data/2.5/weather?q=$ciudad,cr&units=metric&appid=$apiKey"

        GlobalScope.launch(Dispatchers.IO) {
            val resJson = URL(url).readText()

            val jsonObj = JSONObject(resJson)
            val main = jsonObj.getJSONObject("main")
            val temp = main.getDouble("temp")
            val humidity = main.getDouble("humidity")
            val weatherArray = jsonObj.getJSONArray("weather")
            val weatherObj = weatherArray.getJSONObject(0)
            val description = weatherObj.getString("main")

            // Setea los datos
            withContext(Dispatchers.Main) {
                tvTemperatura.text = "Temperatura: $temp °C"
                tvHumedad.text = "Humedad: $humidity %"
                tvDescripcion.text = "Descripción: $description"

                // Se va a cargar la imagen segun la informacion de la descripcion
                val imagenTiempo = when {
                    description.contains("clear", ignoreCase = true) -> R.drawable.soleado
                    description.contains("clouds", ignoreCase = true) -> R.drawable.nublado
                    description.contains("rain", ignoreCase = true) -> R.drawable.lluvioso
                    description.contains("Snow", ignoreCase = true) -> R.drawable.nevado
                    description.contains("Thunderstorm", ignoreCase = true) -> R.drawable.tormenta
                    description.contains("wind", ignoreCase = true) -> R.drawable.ventoso

                    // En caso de que no sea ninguno de los anteriores dejara la imagen de soleado para evitar que se vea como un error o similar
                    else -> R.drawable.soleado
                }
                imgTiempo.setImageResource(imagenTiempo)






            }
        }
    }

}
